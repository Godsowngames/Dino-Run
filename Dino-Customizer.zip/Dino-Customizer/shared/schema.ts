import { pgTable, text, serial, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const games = pgTable("games", {
  id: serial("id").primaryKey(),
  playerName: text("player_name").notNull(),
  profileImage: text("profile_image"),
  jumpSound: text("jump_sound"),
  deathSound: text("death_sound"),
  isPublic: boolean("is_public").default(false),
  gameConfig: jsonb("game_config").default({}),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertGameSchema = createInsertSchema(games).omit({ id: true, createdAt: true });
export type InsertGame = z.infer<typeof insertGameSchema>;
export type Game = typeof games.$inferSelect;
