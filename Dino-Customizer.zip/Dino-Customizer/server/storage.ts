import { db } from "./db";
import {
  games,
  type InsertGame,
  type Game
} from "@shared/schema";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  createGame(game: InsertGame): Promise<Game>;
  getGame(id: number): Promise<Game | undefined>;
  getPublicGames(): Promise<Game[]>;
}

export class DatabaseStorage implements IStorage {
  async createGame(insertGame: InsertGame): Promise<Game> {
    const [game] = await db.insert(games).values(insertGame).returning();
    return game;
  }

  async getGame(id: number): Promise<Game | undefined> {
    const [game] = await db.select().from(games).where(eq(games.id, id));
    return game;
  }

  async getPublicGames(): Promise<Game[]> {
    return await db.select().from(games)
      .where(eq(games.isPublic, true))
      .orderBy(desc(games.createdAt));
  }
}

export const storage = new DatabaseStorage();
