/**
 * Minimal C++ Backend Example using Crow (Microframework)
 * 
 * To compile: g++ backend_example.cpp -o backend -lpthread
 * Dependencies: Crow (https://github.com/CrowCpp/Crow)
 */

#include "crow.h"
#include <unordered_map>
#include <string>
#include <mutex>
#include <vector>

// Game Configuration Structure
struct GameConfig {
    int id;
    std::string playerName;
    std::string profileImage; // Base64
    std::string jumpSound;    // Base64
    std::string deathSound;   // Base64
    bool isPublic;
};

// Simple In-Memory Database
class GameDatabase {
    std::unordered_map<int, GameConfig> games;
    std::mutex mtx;
    int nextId = 1;

public:
    int createGame(const GameConfig& config) {
        std::lock_guard<std::mutex> lock(mtx);
        int id = nextId++;
        GameConfig newGame = config;
        newGame.id = id;
        games[id] = newGame;
        return id;
    }

    GameConfig* getGame(int id) {
        std::lock_guard<std::mutex> lock(mtx);
        if (games.find(id) != games.end()) {
            return &games[id];
        }
        return nullptr;
    }
};

int main() {
    crow::SimpleApp app;
    GameDatabase db;

    // POST /createGame
    CROW_ROUTE(app, "/createGame").methods(crow::HTTPMethod::POST)([&db](const crow::request& req) {
        auto x = crow::json::load(req.body);
        if (!x) return crow::response(400);

        GameConfig config;
        config.playerName = x["playerName"].s();
        config.profileImage = x["profileImage"].s(); // Assuming small base64 for example
        config.jumpSound = x["jumpSound"].s();
        config.deathSound = x["deathSound"].s();
        config.isPublic = x["isPublic"].b();

        int id = db.createGame(config);
        crow::json::wvalue res;
        res["id"] = id;
        res["message"] = "Game created successfully";
        return crow::response(201, res);
    });

    // GET /game/{id}
    CROW_ROUTE(app, "/game/<int>")([&db](int id) {
        GameConfig* game = db.getGame(id);
        if (!game) return crow::response(404, "Game not found");

        crow::json::wvalue res;
        res["id"] = game->id;
        res["playerName"] = game->playerName;
        res["isPublic"] = game->isPublic;
        // In a real app, serve heavy assets via static file server or CDN URLs
        return crow::response(res);
    });

    app.port(8080).multithreaded().run();
}
