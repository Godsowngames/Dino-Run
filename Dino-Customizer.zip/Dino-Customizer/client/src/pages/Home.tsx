import { Link } from "wouter";
import { PixelButton } from "@/components/PixelButton";
import { PixelCard } from "@/components/PixelCard";
import { Gamepad2, Globe, User, Trophy } from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="max-w-4xl w-full grid md:grid-cols-2 gap-8 items-center">
        
        {/* Hero Section */}
        <div className="space-y-8">
          <div className="space-y-2">
            <h1 className="text-5xl md:text-7xl font-pixel leading-tight">
              DINO<br/><span className="text-neutral-400">RUNNER</span>
            </h1>
            <p className="font-mono text-lg text-muted-foreground border-l-4 border-black pl-4 py-2">
              The classic offline experience.<br/>
              Remixed. Customized. Yours.
            </p>
          </div>

          <div className="flex flex-col gap-4 max-w-xs">
            <Link href="/create">
              <PixelButton size="lg" className="w-full group relative overflow-hidden">
                <div className="relative z-10 flex items-center justify-center gap-3">
                  <Gamepad2 className="w-5 h-5" />
                  CREATE GAME
                </div>
              </PixelButton>
            </Link>
            
            <Link href="/public">
              <PixelButton variant="secondary" size="lg" className="w-full">
                <div className="flex items-center justify-center gap-3">
                  <Globe className="w-5 h-5" />
                  PUBLIC GAMES
                </div>
              </PixelButton>
            </Link>

            <Link href="/my-games">
              <PixelButton variant="outline" size="lg" className="w-full">
                <div className="flex items-center justify-center gap-3">
                  <User className="w-5 h-5" />
                  MY GAMES
                </div>
              </PixelButton>
            </Link>
          </div>
        </div>

        {/* Visual Element */}
        <div className="hidden md:block">
          <PixelCard variant="dark" className="transform rotate-2 hover:rotate-0 transition-transform duration-300">
            <div className="aspect-square bg-neutral-900 relative overflow-hidden flex items-center justify-center border-2 border-white/20">
              <div className="absolute inset-0 opacity-20" style={{ backgroundImage: 'linear-gradient(#333 1px, transparent 1px), linear-gradient(90deg, #333 1px, transparent 1px)', backgroundSize: '20px 20px' }}></div>
              
              <div className="text-center space-y-4 relative z-10">
                <Trophy className="w-16 h-16 mx-auto text-yellow-400" />
                <div className="space-y-2">
                  <p className="font-pixel text-xs text-neutral-400">HIGH SCORE</p>
                  <p className="font-pixel text-4xl text-white">00482</p>
                </div>
              </div>

              {/* Decorative pixel dino elements */}
              <div className="absolute bottom-4 left-4 w-8 h-8 bg-white pixel-shadow animate-bounce" />
              <div className="absolute bottom-4 right-12 w-4 h-8 bg-white/50" />
              <div className="absolute bottom-4 right-4 w-4 h-12 bg-white/50" />
            </div>
            <div className="mt-4 flex justify-between items-center text-xs font-mono text-neutral-400">
              <span>PRESS SPACE TO START</span>
              <span className="animate-pulse">INSERT COIN</span>
            </div>
          </PixelCard>
        </div>

      </div>
    </div>
  );
}
