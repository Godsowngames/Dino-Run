import { useEffect, useRef, useState } from "react";
import { useRoute } from "wouter";
import { useGame } from "@/hooks/use-games";
import { PixelButton } from "@/components/PixelButton";
import { ArrowLeft, Loader2, Volume2, VolumeX } from "lucide-react";
import { Link } from "wouter";

declare global {
  interface Window {
    Runner: any;
  }
}

// Convert Data URI to ArrayBuffer for audio context
function base64ToArrayBuffer(base64: string) {
  const binaryString = window.atob(base64.split(',')[1]);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes.buffer;
}

export default function PlayGame() {
  const [, params] = useRoute("/play/:id");
  const id = params ? parseInt(params.id) : 0;
  
  // Try to load from API first
  const { data: apiGame, isLoading, error } = useGame(id);
  const [localGame, setLocalGame] = useState<any>(null);
  
  const containerRef = useRef<HTMLDivElement>(null);
  const runnerInstance = useRef<any>(null);
  const [isMuted, setIsMuted] = useState(false);

  useEffect(() => {
    // If API fails or returns null, check local storage (fallback for private games)
    if (!isLoading && !apiGame) {
      const myGames = JSON.parse(localStorage.getItem("myGames") || "[]");
      const found = myGames.find((g: any) => g.id === id);
      if (found) setLocalGame(found);
    }
  }, [id, apiGame, isLoading]);

  const gameData = apiGame || localGame;

  useEffect(() => {
    if (!gameData || !containerRef.current || !window.Runner) return;

    // Cleanup previous instance
    if (runnerInstance.current) {
      // Basic cleanup if Runner supports it, or just reload page logic might be safer in real prod
      // Since the original dino game is a singleton, we need to be careful.
      // For this demo, we assume a fresh mount.
    }

    const config = {
      id: gameData.id,
      SPEED: 6,
      GRAVITY: 0.6,
    };

    // Initialize the runner
    // We pass our custom configuration attached to the window or runner prototype patches
    // Since we can't easily rewrite the Runner class constructor without heavy patches,
    // we will inject the assets into the DOM or global state before init.
    
    // Inject custom profile image if exists
    if (gameData.profileImage) {
      const style = document.createElement('style');
      style.innerHTML = `
        .runner-container canvas {
          /* Canvas styling handled by runner */
        }
      `;
      document.head.appendChild(style);
    }

    // Audio injection logic would go here
    // The script.js patches would look for specific global variables
    if (gameData.jumpSound) {
      (window as any).customJumpBuffer = base64ToArrayBuffer(gameData.jumpSound);
    }
    if (gameData.deathSound) {
      (window as any).customDeathBuffer = base64ToArrayBuffer(gameData.deathSound);
    }

    try {
      runnerInstance.current = new window.Runner('.runner-container', config);
    } catch (e) {
      console.error("Failed to init runner", e);
    }

    return () => {
      // Cleanup
      (window as any).customJumpBuffer = null;
      (window as any).customDeathBuffer = null;
    };
  }, [gameData]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-neutral-50">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    );
  }

  if (!gameData) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-neutral-50 flex-col gap-4">
        <h1 className="font-pixel text-xl">GAME NOT FOUND</h1>
        <Link href="/">
          <PixelButton>GO HOME</PixelButton>
        </Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-neutral-100 flex flex-col items-center justify-center p-4">
      
      {/* Game Header / HUD */}
      <div className="w-full max-w-[600px] mb-8 flex items-center justify-between">
        <Link href="/">
          <PixelButton size="sm" variant="outline">
            <ArrowLeft className="w-4 h-4 mr-2" /> EXIT
          </PixelButton>
        </Link>
        
        <div className="flex items-center gap-4 bg-white px-4 py-2 border-2 border-black pixel-shadow">
          {gameData.profileImage ? (
            <img src={gameData.profileImage} alt="Player" className="w-8 h-8 rounded pixel-art border border-black" />
          ) : (
            <div className="w-8 h-8 bg-black rounded" />
          )}
          <span className="font-pixel text-sm">{gameData.playerName}</span>
        </div>

        <button onClick={() => setIsMuted(!isMuted)} className="p-2 hover:bg-neutral-200 rounded">
          {isMuted ? <VolumeX className="w-6 h-6" /> : <Volume2 className="w-6 h-6" />}
        </button>
      </div>

      {/* Game Container */}
      <div className="relative">
        <div 
          ref={containerRef} 
          className="runner-container w-[600px] h-[150px] bg-white border-4 border-black pixel-shadow overflow-hidden relative"
        >
          {/* Canvas injected here by Runner */}
        </div>
        
        {/* Retro TV Scanline Effect Overlay */}
        <div className="absolute inset-0 pointer-events-none opacity-10 bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))]" style={{ backgroundSize: "100% 2px, 3px 100%" }} />
      </div>

      <div className="mt-12 text-center space-y-2">
        <p className="font-mono text-sm text-neutral-500 animate-pulse">PRESS SPACE TO JUMP • DOWN TO DUCK</p>
        <p className="font-pixel text-xs text-neutral-400">ID: {gameData.id}</p>
      </div>

    </div>
  );
}
