import { Link } from "wouter";
import { usePublicGames } from "@/hooks/use-games";
import { PixelCard } from "@/components/PixelCard";
import { PixelButton } from "@/components/PixelButton";
import { ArrowLeft, Play, User, Clock, Loader2 } from "lucide-react";

export default function PublicGames() {
  const { data: games, isLoading } = usePublicGames();

  return (
    <div className="min-h-screen bg-neutral-50 p-4 md:p-8">
      <div className="max-w-5xl mx-auto space-y-8">
        
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/">
              <PixelButton size="sm" variant="secondary">
                <ArrowLeft className="w-4 h-4" />
              </PixelButton>
            </Link>
            <h1 className="text-2xl md:text-3xl font-pixel">PUBLIC ARCADE</h1>
          </div>
          <Link href="/create">
            <PixelButton size="sm">NEW GAME</PixelButton>
          </Link>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin" />
          </div>
        ) : games && games.length > 0 ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {games.map((game) => (
              <PixelCard key={game.id} className="hover:-translate-y-1 transition-transform cursor-pointer group">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    {game.profileImage ? (
                      <img src={game.profileImage} alt={game.playerName} className="w-10 h-10 border-2 border-black pixel-art bg-neutral-100" />
                    ) : (
                      <div className="w-10 h-10 bg-black border-2 border-black flex items-center justify-center text-white">
                        <User className="w-5 h-5" />
                      </div>
                    )}
                    <div>
                      <h3 className="font-pixel text-xs">{game.playerName}</h3>
                      <span className="text-xs font-mono text-muted-foreground">Game #{game.id}</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex gap-2 text-xs font-mono text-muted-foreground">
                    <span className="bg-neutral-100 px-2 py-1 rounded border border-neutral-200 flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {new Date(game.createdAt || Date.now()).toLocaleDateString()}
                    </span>
                  </div>

                  <Link href={`/play/${game.id}`} className="block">
                    <PixelButton className="w-full group-hover:bg-neutral-800">
                      <Play className="w-4 h-4 mr-2" /> PLAY NOW
                    </PixelButton>
                  </Link>
                </div>
              </PixelCard>
            ))}
          </div>
        ) : (
          <div className="text-center py-20 bg-white border-4 border-dashed border-neutral-200">
            <p className="font-pixel text-neutral-400 mb-4">NO GAMES FOUND</p>
            <Link href="/create">
              <PixelButton>BE THE FIRST</PixelButton>
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}
