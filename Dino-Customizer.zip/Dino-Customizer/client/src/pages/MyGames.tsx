import { useState, useEffect } from "react";
import { Link } from "wouter";
import { PixelCard } from "@/components/PixelCard";
import { PixelButton } from "@/components/PixelButton";
import { ArrowLeft, Play, User, Trash2 } from "lucide-react";
import { type Game } from "@shared/schema";

export default function MyGames() {
  const [games, setGames] = useState<Game[]>([]);

  useEffect(() => {
    const localGames = JSON.parse(localStorage.getItem("myGames") || "[]");
    setGames(localGames);
  }, []);

  const deleteGame = (id: number) => {
    if (!confirm("Delete this game?")) return;
    const newGames = games.filter(g => g.id !== id);
    setGames(newGames);
    localStorage.setItem("myGames", JSON.stringify(newGames));
  };

  return (
    <div className="min-h-screen bg-neutral-50 p-4 md:p-8">
      <div className="max-w-5xl mx-auto space-y-8">
        
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/">
              <PixelButton size="sm" variant="secondary">
                <ArrowLeft className="w-4 h-4" />
              </PixelButton>
            </Link>
            <h1 className="text-2xl md:text-3xl font-pixel">MY CARTRIDGES</h1>
          </div>
          <Link href="/create">
            <PixelButton size="sm">NEW GAME</PixelButton>
          </Link>
        </div>

        {games.length > 0 ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {games.map((game) => (
              <PixelCard key={game.id} className="hover:-translate-y-1 transition-transform group">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    {game.profileImage ? (
                      <img src={game.profileImage} alt={game.playerName} className="w-10 h-10 border-2 border-black pixel-art bg-neutral-100" />
                    ) : (
                      <div className="w-10 h-10 bg-black border-2 border-black flex items-center justify-center text-white">
                        <User className="w-5 h-5" />
                      </div>
                    )}
                    <div>
                      <h3 className="font-pixel text-xs">{game.playerName}</h3>
                      <span className="text-xs font-mono text-muted-foreground">
                        {game.isPublic ? "PUBLIC" : "PRIVATE"}
                      </span>
                    </div>
                  </div>
                  <button 
                    onClick={() => deleteGame(game.id)}
                    className="text-neutral-400 hover:text-red-500 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                <div className="space-y-4">
                  <Link href={`/play/${game.id}`} className="block">
                    <PixelButton className="w-full group-hover:bg-neutral-800">
                      <Play className="w-4 h-4 mr-2" /> PLAY NOW
                    </PixelButton>
                  </Link>
                </div>
              </PixelCard>
            ))}
          </div>
        ) : (
          <div className="text-center py-20 bg-white border-4 border-dashed border-neutral-200">
            <p className="font-pixel text-neutral-400 mb-4">NO LOCAL GAMES FOUND</p>
            <Link href="/create">
              <PixelButton>CREATE ONE</PixelButton>
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}
