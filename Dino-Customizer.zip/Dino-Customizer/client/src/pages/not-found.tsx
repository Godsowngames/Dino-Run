import { Link } from "wouter";
import { PixelCard } from "@/components/PixelCard";
import { PixelButton } from "@/components/PixelButton";
import { AlertTriangle } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-neutral-50 p-4">
      <PixelCard className="max-w-md w-full text-center space-y-6">
        <AlertTriangle className="w-16 h-16 mx-auto text-neutral-400" />
        
        <div className="space-y-2">
          <h1 className="text-4xl font-pixel">404</h1>
          <p className="font-mono text-muted-foreground">GAME OVER</p>
        </div>

        <p className="font-mono text-sm">
          The page you are looking for has been eaten by a T-Rex.
        </p>

        <Link href="/">
          <PixelButton className="w-full">
            INSERT COIN TO RESTART
          </PixelButton>
        </Link>
      </PixelCard>
    </div>
  );
}
