import { useState } from "react";
import { useLocation } from "wouter";
import { PixelButton } from "@/components/PixelButton";
import { RetroInput } from "@/components/RetroInput";
import { FileUpload } from "@/components/FileUpload";
import { PixelCard } from "@/components/PixelCard";
import { useCreateGame } from "@/hooks/use-games";
import { ArrowLeft, Save, Globe, Lock } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function CreateGame() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const createGame = useCreateGame();
  
  const [formData, setFormData] = useState({
    playerName: "",
    isPublic: false,
    profileImage: null as string | null,
    jumpSound: null as string | null,
    deathSound: null as string | null,
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.playerName) {
      toast({ title: "Error", description: "Player name is required", variant: "destructive" });
      return;
    }

    try {
      const result = await createGame.mutateAsync({
        playerName: formData.playerName,
        isPublic: formData.isPublic,
        profileImage: formData.profileImage,
        jumpSound: formData.jumpSound,
        deathSound: formData.deathSound,
        gameConfig: {},
      });

      // Save to local storage for "My Games"
      const myGames = JSON.parse(localStorage.getItem("myGames") || "[]");
      myGames.push(result);
      localStorage.setItem("myGames", JSON.stringify(myGames));

      toast({ title: "Success!", description: "Game created successfully." });
      setLocation(`/play/${result.id}`);
    } catch (error) {
      toast({ title: "Failed", description: "Could not create game.", variant: "destructive" });
    }
  };

  return (
    <div className="min-h-screen bg-neutral-50 p-4 md:p-8">
      <div className="max-w-3xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex items-center gap-4">
          <PixelButton size="sm" variant="secondary" onClick={() => setLocation("/")}>
            <ArrowLeft className="w-4 h-4" />
          </PixelButton>
          <h1 className="text-2xl font-pixel">CONFIGURE RUNNER</h1>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="grid md:grid-cols-3 gap-8">
            {/* Main Form */}
            <div className="md:col-span-2 space-y-6">
              <PixelCard>
                <div className="space-y-6">
                  <RetroInput 
                    label="Player Name" 
                    placeholder="ENTER NAME..." 
                    value={formData.playerName}
                    onChange={(e) => setFormData(prev => ({ ...prev, playerName: e.target.value }))}
                    maxLength={10}
                  />

                  <div className="grid grid-cols-2 gap-4">
                    <FileUpload 
                      label="Custom Jump SFX" 
                      accept="audio/*" 
                      type="audio"
                      onFileSelect={(f) => setFormData(prev => ({ ...prev, jumpSound: f }))}
                    />
                    <FileUpload 
                      label="Custom Death SFX" 
                      accept="audio/*" 
                      type="audio"
                      onFileSelect={(f) => setFormData(prev => ({ ...prev, deathSound: f }))}
                    />
                  </div>
                </div>
              </PixelCard>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              <PixelCard className="space-y-4">
                <div className="font-pixel text-xs uppercase text-muted-foreground mb-4">Profile Picture</div>
                <FileUpload 
                  label=""
                  accept="image/*" 
                  type="image"
                  onFileSelect={(f) => setFormData(prev => ({ ...prev, profileImage: f }))}
                  className="w-full"
                />
              </PixelCard>

              <PixelCard>
                <div className="space-y-4">
                  <div className="font-pixel text-xs uppercase text-muted-foreground">Visibility</div>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setFormData(prev => ({ ...prev, isPublic: false }))}
                      className={`flex-1 p-3 border-2 flex flex-col items-center gap-2 transition-all ${!formData.isPublic ? 'bg-black text-white border-black' : 'bg-white border-neutral-200 text-neutral-400'}`}
                    >
                      <Lock className="w-5 h-5" />
                      <span className="text-xs font-pixel">PRIVATE</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setFormData(prev => ({ ...prev, isPublic: true }))}
                      className={`flex-1 p-3 border-2 flex flex-col items-center gap-2 transition-all ${formData.isPublic ? 'bg-black text-white border-black' : 'bg-white border-neutral-200 text-neutral-400'}`}
                    >
                      <Globe className="w-5 h-5" />
                      <span className="text-xs font-pixel">PUBLIC</span>
                    </button>
                  </div>
                </div>
              </PixelCard>

              <PixelButton 
                type="submit" 
                className="w-full py-6 text-lg" 
                disabled={createGame.isPending}
              >
                {createGame.isPending ? "CREATING..." : (
                  <span className="flex items-center justify-center gap-2">
                    <Save className="w-5 h-5" /> START GAME
                  </span>
                )}
              </PixelButton>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}
