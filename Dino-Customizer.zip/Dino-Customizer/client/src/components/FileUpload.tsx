import { useState, useRef } from "react";
import { cn } from "@/lib/utils";
import { Upload, X, Music, Image as ImageIcon, Play, Pause } from "lucide-react";
import { PixelButton } from "./PixelButton";

interface FileUploadProps {
  label: string;
  accept: string;
  type: "image" | "audio";
  onFileSelect: (base64: string | null) => void;
  className?: string;
}

export function FileUpload({ label, accept, type, onFileSelect, className }: FileUploadProps) {
  const [preview, setPreview] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate size (max 2MB for demo purposes)
    if (file.size > 2 * 1024 * 1024) {
      alert("File is too large (max 2MB)");
      return;
    }

    const reader = new FileReader();
    reader.onloadend = () => {
      const result = reader.result as string;
      setPreview(result);
      onFileSelect(result);
    };
    reader.readAsDataURL(file);
  };

  const clearFile = () => {
    setPreview(null);
    onFileSelect(null);
    if (inputRef.current) inputRef.current.value = "";
    if (audioRef.current) {
      audioRef.current.pause();
      setIsPlaying(false);
    }
  };

  const toggleAudio = () => {
    if (!audioRef.current && preview) {
      audioRef.current = new Audio(preview);
      audioRef.current.onended = () => setIsPlaying(false);
    }
    
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
      } else {
        audioRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  return (
    <div className={cn("flex flex-col gap-2", className)}>
      <span className="font-pixel text-xs uppercase text-muted-foreground">{label}</span>
      
      {!preview ? (
        <div 
          onClick={() => inputRef.current?.click()}
          className="border-2 border-dashed border-neutral-300 hover:border-black cursor-pointer bg-neutral-50 hover:bg-neutral-100 p-4 flex flex-col items-center justify-center gap-2 h-32 transition-colors"
        >
          {type === "image" ? <ImageIcon className="w-8 h-8 opacity-20" /> : <Music className="w-8 h-8 opacity-20" />}
          <span className="text-xs text-muted-foreground font-mono">Click to upload</span>
        </div>
      ) : (
        <div className="relative border-2 border-black bg-white p-2 flex items-center gap-4 h-32">
          {type === "image" ? (
            <img src={preview} alt="Preview" className="h-full w-auto object-contain pixel-art mx-auto" />
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center gap-2">
              <div className="w-full h-8 bg-neutral-100 flex items-center justify-center overflow-hidden">
                <div className="flex gap-1 items-end h-4">
                  {[...Array(10)].map((_, i) => (
                    <div 
                      key={i} 
                      className={cn(
                        "w-1 bg-black transition-all duration-100", 
                        isPlaying ? "animate-pulse" : ""
                      )}
                      style={{ height: isPlaying ? `${Math.random() * 100}%` : '20%' }}
                    />
                  ))}
                </div>
              </div>
              <PixelButton 
                type="button" 
                size="sm" 
                variant="outline" 
                onClick={toggleAudio}
                className="w-full flex items-center justify-center gap-2"
              >
                {isPlaying ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
                {isPlaying ? "STOP" : "PLAY"}
              </PixelButton>
            </div>
          )}
          
          <button 
            onClick={clearFile}
            className="absolute -top-2 -right-2 bg-red-500 text-white border-2 border-black w-6 h-6 flex items-center justify-center hover:bg-red-600 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      <input 
        ref={inputRef}
        type="file" 
        accept={accept} 
        onChange={handleFileChange} 
        className="hidden" 
      />
    </div>
  );
}
