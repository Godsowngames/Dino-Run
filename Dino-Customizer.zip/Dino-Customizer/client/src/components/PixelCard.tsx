import { cn } from "@/lib/utils";

interface PixelCardProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode;
  variant?: "default" | "dark";
}

export function PixelCard({ children, className, variant = "default", ...props }: PixelCardProps) {
  return (
    <div
      className={cn(
        "relative p-6 border-4 border-black transition-transform duration-200 pixel-shadow",
        variant === "dark" ? "bg-black text-white" : "bg-white text-black",
        className
      )}
      {...props}
    >
      {/* Corner decorations for extra pixel feel */}
      <div className={cn("absolute -top-1 -left-1 w-2 h-2", variant === "dark" ? "bg-white" : "bg-black")} />
      <div className={cn("absolute -top-1 -right-1 w-2 h-2", variant === "dark" ? "bg-white" : "bg-black")} />
      <div className={cn("absolute -bottom-1 -left-1 w-2 h-2", variant === "dark" ? "bg-white" : "bg-black")} />
      <div className={cn("absolute -bottom-1 -right-1 w-2 h-2", variant === "dark" ? "bg-white" : "bg-black")} />
      
      {children}
    </div>
  );
}
