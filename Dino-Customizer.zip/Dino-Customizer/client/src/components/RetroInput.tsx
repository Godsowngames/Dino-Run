import React from "react";
import { cn } from "@/lib/utils";

interface RetroInputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
}

export const RetroInput = React.forwardRef<HTMLInputElement, RetroInputProps>(
  ({ className, label, ...props }, ref) => {
    return (
      <div className="flex flex-col gap-2">
        {label && (
          <label className="font-pixel text-xs uppercase text-muted-foreground">
            {label}
          </label>
        )}
        <input
          ref={ref}
          className={cn(
            "w-full px-4 py-3 bg-white border-2 border-black font-mono text-lg",
            "focus:outline-none focus:ring-4 focus:ring-black/10 transition-all",
            "placeholder:text-neutral-300",
            className
          )}
          {...props}
        />
      </div>
    );
  }
);
RetroInput.displayName = "RetroInput";
