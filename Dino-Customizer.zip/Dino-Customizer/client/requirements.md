## Packages
(none needed)

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  pixel: ["'Press Start 2P'", "cursive"],
  mono: ["'Courier New'", "monospace"],
}
Game Logic:
The actual game canvas logic relies on the existing `script.js` which defines `window.Runner`.
This React app handles the configuration wrapper and mounting the game.
